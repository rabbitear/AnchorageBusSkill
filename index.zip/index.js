// Skill for Anchorage Bus
var Alexa = require('alexa-sdk');
var http = require('http');

const skillName = "Anchorage Bus";

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = process.env.ALEXA_APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    "WhenNextBusIntent": function() {
        var whereto = this.event.request.intent.slots.ToWhere.value;
        var speechOutput = "";
        if(whereto && whereto.toLowerCase() == "downtown") {
            var nextBusTime = getNextBusTime(1632);
            speechOutput = "The next Bus 7 to inbound to Downtown"+
                "is at " + nextBusTime + ".";
        } else if(whereto && whereto.toLowerCase() == "diamond center") {
            var nextBusTime = getNextBusTime(1615);
            speechOutput = "The next Bus 7 outbound to Diamond Center"+
                "is at " + nextBusTime + ".";
        } else {
            speechOutput = "I don't have that destination in the database."
        }
        this.emit(':tell', speechOutput);
    },

    "AMAZON.StopIntent": function () {
        var speechOutput = "Goodbye";
        this.emit(':tell', speechOutput);
    },

    "AMAZON.CancelIntent": function () {
        var speechOutput = "Goodbye";
        this.emit(':tell', speechOutput);
    },

    "LaunchRequest": function() {
        var speechText = "";
        speechText += "Welcome to " + skillName + ". ";
        speechText += "Please say your destination for bus number 7, either downtown or diamond center."
        var repromptText = "For instructions on what you can say, please sayhelp me."
        this.emit(':ask', speechText, repromptText);
    }
};



// get groups out of a regex.
function getMatches(string, regex, index) {
  index || (index = 1);
  var matches = [];
  var match;
  while (match = regex.exec(string)) {
    matches.push(match[index]);
  }
  return matches;
}

function getNextBusTime(busStop)
    // busStop ex: 1632
    var options = {
        host: 'bustracker.muni.org',
        path: '/InfoPoint/departures.aspx?stopid=' + busStop
    }
    var nextBusTime = "";
    http.request(options, function(response) {
        var str = '';
        // another chunk of data has been recieved, 
        // so append it to str.
        response.on('data', function (chunk) {
            str += chunk;
        });
        // the whole response has been recieved, here.
        response.on('end', function () {
            // regex looks for times: 
            // <div class='departure'>04:57 PM</div>
            var rePattern = /<div[^<>]*\ class=\'departure\'[^<>]*>(\d\d:\d\d\s\w+)<\/div>/g;
            var matches = getMatches(str, rePattern, 1);
            nextBusTime = matches[1];
        });
    }).end();
    return nextBusTime;
}

